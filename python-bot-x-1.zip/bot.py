#### RIGH NIX #####

from config import *
import telebot
import threading
import time
bot = telebot.TeleBot("6389054499:AAH1zWP2RbeKi4YL7CJsuDewvsRldVrtwk0")

CHANNEL_NAME = "@raven_ccs"




def send_file_lines_to_channel(cc):
  with open(cc, "r") as file:
    for line in file:
      cc = line
      bot.send_message(CHANNEL_NAME, "<b>╔═══════════════════════╗\n╟●   𝕊ℂℝ𝔸ℙℙ𝔼ℝ 𝕍𝕀ℙ   \n╟═══════════════════════╝\n╟ ● CC: <code>{}</code>╟════════════════════════\n╟ ● REFERENCIAS: @OWNERB3\n╟════════════════════════\n╟ ● SCRAPPER BY: @OWNERB3\n╚═══════════════════════╝</b>".format(cc), parse_mode="html")
      time.sleep(10)
      print(cc)


send_file_lines_to_channel("cc.txt")




def recibir_msg():
    bot.infinity_polling()

          ######## MAIN #########

if __name__ == '__main__':
    print('iniciando')
    hilo_bot = threading.Thread(name="hilo_bot", target=recibir_msg)
    hilo_bot.start()
    print('fin')